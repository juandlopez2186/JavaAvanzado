package model;
import java.sql.*;
public class UsuarioDAO {
    public class HashtagDAO extends Connect{
        Connection con; 
        PreparedStatement ps; 
        ResultSet rs; 
        String sql=null;  
    public void addusuarios() {
        try{
        
  String sql = "INSERT INTO Usuario (Nombre, Username,Correo_electrónico,Contraseña,Ubicación,Descripción,Fecha_de_registro) VALUES (?,?,?,?,?,?,?)";
  PreparedStatement statement = con.prepareStatement(sql);

  statement.setString(1, "Nombre");
  statement.setString(2, "Username");
  statement.setString(3, "Correo_electrónico");
  statement.setString(4, "Contraseña");
  statement.setString(5, "Ubicación");
  statement.setString(6, "Descripción");
  statement.setString(7, "Fecha_de_registro");

  statement.executeUpdate();

  statement.close();
  con.close();
} 
catch (SQLException es) {
  es.printStackTrace();
}
}
public void listusuario() {
    try {
        String sql = "SELECT * FROM USUARIO WHERE Username=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "Username");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
    
}
public void delusuario() {
    try {
        String sql = "DELETE * FROM USUARIO WHERE Username=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "Username");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
    
}
}
 
}
