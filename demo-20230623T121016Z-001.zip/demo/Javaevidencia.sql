create database twitter;
use twitter;
create table Usuario(
ID_Usuario int primary key auto_increment,
Nombre varchar(255),
Username varchar(255),
Correo_electrónico varchar(255),
Contraseña varchar(255),
Ubicación varchar(255),
Descripción varchar(255),
Fecha_de_registro date
);
create table tweet(
ID_Tweet int primary key auto_increment,
Contenido varchar(255),
Fecha_de_creación date,
ID_Usuario int
);
create table Seguidor(
ID_Seguidor int primary key,
ID_Usuario int
);
create table Hashtag(
ID_Hashtag int primary key,
Nombre varchar(255),
ID_Tweet int
);
alter table Seguidor add  foreign key (ID_Usuario) references Usuario (ID_Usuario);
alter table tweet add  foreign key (ID_Usuario) references Usuario (ID_Usuario);
alter table Hashtag add  foreign key (ID_Tweet) references tweet (ID_Tweet);