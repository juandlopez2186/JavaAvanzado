package controller;


import java.io.IOException;
import model.UsuarioVO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.UsuarioDAO;


public class Usuario extends HttpServlet{
    UsuarioVO b=new UsuarioVO();
    UsuarioDAO a=new UsuarioDAO();
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String h=req.getParameter("h");
        switch(h){
            case "log":
            req.getRequestDispatcher("views/usuario/log.jsp").forward(req, resp);
            break;
            case "controles":
            req.getRequestDispatcher("views/usuario/controles.jsp").forward(req, resp);
            break;
            case "ctweet":
            req.getRequestDispatcher("ctweet.jsp").forward(req, resp);
            break;
            case "usuarioadd":
            req.getRequestDispatcher("views/usuario/usuarioadd.jsp").forward(req, resp);
            break;
            case "index.jps":
            req.getRequestDispatcher("views/usuario/index.jsp").forward(req, resp);
            break;
            case "cons":
            req.getRequestDispatcher("views/seguidor/seguidorlist.jsp").forward(req, resp);
            break;
            case "delete":
            req.getRequestDispatcher("views/seguidor/seguidordelete.jsp").forward(req, resp);
            break;
        }
        super.doGet(req, resp);
    }
}
 
