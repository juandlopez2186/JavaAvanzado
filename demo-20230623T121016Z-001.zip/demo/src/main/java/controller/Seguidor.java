package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Seguidor extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String h=req.getParameter("h");
        switch(h){
            case "log":
            req.getRequestDispatcher("log.jsp").forward(req, resp);
            break;
            case "controles":
            req.getRequestDispatcher("controles.jsp").forward(req, resp);
            break;
            case "ctweet":
            req.getRequestDispatcher("ctweet.jsp").forward(req, resp);
            break;
            case "etiquetas":
            req.getRequestDispatcher("etiquetas.jsp").forward(req, resp);
            break;
            case "index.jps":
            req.getRequestDispatcher("index.jsp").forward(req, resp);
            break;
            case "cons":
            req.getRequestDispatcher("cons.jsp").forward(req, resp);
            break;
        }
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }

}
