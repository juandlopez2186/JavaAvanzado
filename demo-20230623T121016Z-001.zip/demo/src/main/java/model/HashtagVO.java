package model;

public class HashtagVO {
    private String ID_hashtag="";
    private String Nombre="";
    private String ID_Tweet="";
    public HashtagVO() {
    }
    public HashtagVO(String iD_hashtag, String nombre, String iD_Tweet) {
        ID_hashtag = iD_hashtag;
        Nombre = nombre;
        ID_Tweet = iD_Tweet;
    }
    public String getID_hashtag() {
        return ID_hashtag;
    }
    public void setID_hashtag(String iD_hashtag) {
        ID_hashtag = iD_hashtag;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String nombre) {
        Nombre = nombre;
    }
    public String getID_Tweet() {
        return ID_Tweet;
    }
    public void setID_Tweet(String iD_Tweet) {
        ID_Tweet = iD_Tweet;
    }
    
}
