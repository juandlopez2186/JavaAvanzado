package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SeguidorDAO extends Connect {
    Connection con; 
        PreparedStatement ps; 
        ResultSet rs; 
        String sql=null;  
public void listhashtag() {
    try {
        String sql = "SELECT * FROM seguidor WHERE ID_Seguidor=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "ID_Seguidor");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
    
}
public void delseguidor() {
   try {
        String sql = "DELETE * FROM seguidor WHERE ID_Seguidor=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "ID_Seguidor");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
}
}
