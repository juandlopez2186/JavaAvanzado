package model;

public class TweetVO {
    private String ID_Tweet="";
    private String Contenido="";
    private String Fecha_de_creacion="";
    private String ID_Usuario="";
    public TweetVO() {
    }
    public TweetVO(String iD_Tweet, String contenido, String fecha_de_creacion, String iD_Usuario) {
        ID_Tweet = iD_Tweet;
        Contenido = contenido;
        Fecha_de_creacion = fecha_de_creacion;
        ID_Usuario = iD_Usuario;
    }
    public String getID_Tweet() {
        return ID_Tweet;
    }
    public void setID_Tweet(String iD_Tweet) {
        ID_Tweet = iD_Tweet;
    }
    public String getContenido() {
        return Contenido;
    }
    public void setContenido(String contenido) {
        Contenido = contenido;
    }
    public String getFecha_de_creacion() {
        return Fecha_de_creacion;
    }
    public void setFecha_de_creacion(String fecha_de_creacion) {
        Fecha_de_creacion = fecha_de_creacion;
    }
    public String getID_Usuario() {
        return ID_Usuario;
    }
    public void setID_Usuario(String iD_Usuario) {
        ID_Usuario = iD_Usuario;
    }
    
}
