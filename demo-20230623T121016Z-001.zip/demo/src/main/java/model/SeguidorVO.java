package model;

public class SeguidorVO {
    private String ID_Seguidor="";
    private String ID_Usuario="";
    public SeguidorVO() {
    }
    public SeguidorVO(String iD_Seguidor, String iD_Usuario) {
        ID_Seguidor = iD_Seguidor;
        ID_Usuario = iD_Usuario;
    }
    public String getID_Seguidor() {
        return ID_Seguidor;
    }
    public void setID_Seguidor(String iD_Seguidor) {
        ID_Seguidor = iD_Seguidor;
    }
    public String getID_Usuario() {
        return ID_Usuario;
    }
    public void setID_Usuario(String iD_Usuario) {
        ID_Usuario = iD_Usuario;
    }
    
}
