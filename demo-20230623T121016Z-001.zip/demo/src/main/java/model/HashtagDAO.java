package model;
import java.sql.*;

public class HashtagDAO extends Connect{
        Connection con; 
        PreparedStatement ps; 
        ResultSet rs; 
        String sql=null;  
    public void addhashtag() {
        try{
        
  String sql = "INSERT INTO Hashtag (ID_Hashtag, Nombre,ID_Tweet) VALUES (?,?,?)";
  PreparedStatement statement = con.prepareStatement(sql);

  statement.setString(1, "ID_Hashtag");
  statement.setString(2, "Nombre");
  statement.setString(3, "ID_Tweet");

  statement.executeUpdate();

  statement.close();
  con.close();
} 
catch (SQLException es) {
  es.printStackTrace();
}
}
public void listhashtag() {
    try {
        String sql = "SELECT * FROM hashtag WHERE Nombre=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "Nombre");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
    
}
public void del() {
   try {
        String sql = "DELETE * FROM hashtag WHERE Nombre=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "Nombre");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
}
}
