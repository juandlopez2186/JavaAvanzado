package model;

import java.sql.DriverManager;
import java.sql.Connection;

public class Connect {
    private static final String bbdd="jdbc:mysql://localhost:3306/Twitter";
    private static final String user="root";
    private static final String password="";
    private static Connection con;
    
    public static Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection(bbdd, user, password);
            System.out.println("conexion exitosa");
        } catch (Exception e) {
            System.out.println("error"+e.getMessage().toString());
        }
        return con;
    }
    public static void main() {
        Connect.conectar();
    }
}
