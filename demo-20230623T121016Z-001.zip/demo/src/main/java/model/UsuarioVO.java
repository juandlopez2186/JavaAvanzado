package model;

public class UsuarioVO {
    private String ID_Usuario="";
    private String Nombre="";
    private String Username="";
    private String Correo_electrónico="";
    private String Contraseña="";
    private String Ubicación="";
    private String Descripción="";
    private String Fecha_de_registro="";
    public UsuarioVO() {
    }
    public UsuarioVO(String iD_Usuario, String nombre, String username, String correo_electrónico, String contraseña,
            String ubicación, String descripción, String fecha_de_registro) {
        ID_Usuario = iD_Usuario;
        Nombre = nombre;
        Username = username;
        Correo_electrónico = correo_electrónico;
        Contraseña = contraseña;
        Ubicación = ubicación;
        Descripción = descripción;
        Fecha_de_registro = fecha_de_registro;
    }
    public String getID_Usuario() {
        return ID_Usuario;
    }
    public void setID_Usuario(String iD_Usuario) {
        ID_Usuario = iD_Usuario;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String nombre) {
        Nombre = nombre;
    }
    public String getUsername() {
        return Username;
    }
    public void setUsername(String username) {
        Username = username;
    }
    public String getCorreo_electrónico() {
        return Correo_electrónico;
    }
    public void setCorreo_electrónico(String correo_electrónico) {
        Correo_electrónico = correo_electrónico;
    }
    public String getContraseña() {
        return Contraseña;
    }
    public void setContraseña(String contraseña) {
        Contraseña = contraseña;
    }
    public String getUbicación() {
        return Ubicación;
    }
    public void setUbicación(String ubicación) {
        Ubicación = ubicación;
    }
    public String getDescripción() {
        return Descripción;
    }
    public void setDescripción(String descripción) {
        Descripción = descripción;
    }
    public String getFecha_de_registro() {
        return Fecha_de_registro;
    }
    public void setFecha_de_registro(String fecha_de_registro) {
        Fecha_de_registro = fecha_de_registro;
    }
    
}
