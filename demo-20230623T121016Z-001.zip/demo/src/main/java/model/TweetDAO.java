package model;
import java.sql.*;

public class TweetDAO extends Connect{
        Connection con; 
        PreparedStatement ps; 
        ResultSet rs; 
        String sql=null;  
    public void addtweet() {
        try{
        
  String sql = "INSERT INTO Hashtag (ID_Tweet, Contenido,Fecha_de_creacion,ID_Usuario) VALUES (?,?,?,?)";
  PreparedStatement statement = con.prepareStatement(sql);

  statement.setString(1, "ID_Tweet");
  statement.setString(2, "Contenido");
  statement.setString(3, "Fecha_de_creacion");
  statement.setString(4, "ID_Usuario");

  statement.executeUpdate();

  statement.close();
  con.close();
} 
catch (SQLException es) {
  es.printStackTrace();
}
}
public void listtweet() {
    try {
        String sql = "SELECT * FROM tweet WHERE ID_Tweet=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "ID_Tweet");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
    
}
public void deltweet() {
   try {
        String sql = "DELETE * FROM tweet WHERE ID_Tweet=h";
        PreparedStatement statement =con.prepareStatement(sql);
    
        statement.setString(2, "ID_Tweet");
        
        statement.executeQuery();
    
        statement.close();
        con.close();
        
    } catch (Exception e) {
    }
}
}

